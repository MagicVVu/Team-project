# MagicVVu v0.2 / 旧 v0.3 → v0.3.1 安全升级说明

适用：既有目录 `/srv/magicvvu/magicvvu-starter`，Compose 服务 `backend` 与 `db` 均健康。使用 bash/Ubuntu 终端。

> **本包尚未在你的云服务器运行**；以下命令必须分段执行并检查退出码。不要在 SSH 交互式 Shell 中启用 `set -e`。升级前备份源码、数据库与环境变量。不要执行 `docker compose down -v`，不要强制 Alembic downgrade。

## 1. Windows 上传包

下载 `magicvvu-backend-v0.3-shared-shopping.tar.gz` 至 Downloads，在 Windows PowerShell 执行：

```powershell
scp "$env:USERPROFILE\Downloads\magicvvu-backend-v0.3-shared-shopping.tar.gz" magicvvu:~/
```

## 2. Ubuntu 检查包、确认旧迁移版本

```bash
set +e
cd /srv/magicvvu/magicvvu-starter
ls -lh ~/magicvvu-backend-v0.3-shared-shopping.tar.gz
tar -tzf ~/magicvvu-backend-v0.3-shared-shopping.tar.gz | grep -E '(models.py|0001_core_tables.py|0002_shared_shopping.py|shopping.py|compose.yaml)'
echo "ARCHIVE CHECK EXIT CODE: ${PIPESTATUS[0]}"
```

确认 `ARCHIVE CHECK EXIT CODE: 0`，并显示迁移 `0001`、`0002` 文件。

旧版本信息仅供参考（旧 v0.2 可能未出现迁移版本）：

```bash
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml exec -T backend alembic current
```

## 3. 先备份当前项目及密码文件

```bash
cd /srv/magicvvu/magicvvu-starter
STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="/srv/magicvvu/backups/shared_v03_$STAMP"
mkdir -p "$BACKUP"
chmod 700 /srv/magicvvu/backups "$BACKUP"
cp -a backend deploy/compose.yaml "$BACKUP/"
cp -a deploy/.env "$BACKUP/database-env.backup"
chmod 600 "$BACKUP/database-env.backup"
echo "BACKUP: $BACKUP"
ls -lah "$BACKUP"
```

数据库备份（**检查退出码和非空文件**；备份文件不得公开）：

```bash
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
  exec -T db sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" exec pg_dump -h 127.0.0.1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc --no-owner' \
  > "$BACKUP/postgres_before_shared_v03.dump"
echo "DB BACKUP EXIT CODE: $?"
ls -lh "$BACKUP/postgres_before_shared_v03.dump"
```

如失败，停止操作；不要升级。重要数据库备份另存服务器之外。

## 4. 安装新版本文件（不覆盖 .env）

```bash
cd /srv/magicvvu/magicvvu-starter
tar -xzf ~/magicvvu-backend-v0.3-shared-shopping.tar.gz -C .
echo "EXTRACT EXIT CODE: $?"
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml config --quiet
echo "CONFIG EXIT CODE: $?"
```

两个退出码必须均为 0；`deploy/.env` 与 Docker 命名卷不会被替换。

## 5. 只构建新 backend 镜像，旧服务仍运行

```bash
timeout 360s sudo docker compose --env-file deploy/.env \
  -f deploy/compose.yaml build backend
echo "BUILD EXIT CODE: $?"
```

仅在返回 0 时继续。

## 6. 执行 Alembic 迁移

```bash
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
  run --rm --no-deps backend alembic upgrade head
echo "MIGRATION EXIT CODE: $?"
```

- 从 v0.2 开始执行 0001 → 0002。
- 从已迁移旧 v0.3 继续执行 0002。
- 如果检测到同一家有多张清单，迁移会主动中止，请保留数据并联系开发者合并，不要强制删表或降级。

## 7. 仅更新 FastAPI 容器

```bash
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
  up -d --no-deps backend
echo "BACKEND DEPLOY EXIT CODE: $?"
```

不会主动重启 `db` 容器。

## 8. 检查业务表、回滚式内部购买入库测试

```bash
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml ps
curl -i --max-time 10 http://127.0.0.1:8000/api/v1/health
curl -i --max-time 10 http://127.0.0.1:8000/api/v1/ready
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
  exec -T backend alembic current
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
  exec -T backend python -m app.schema_smoke
echo "SMOKE EXIT CODE: $?"
```

预期：两个容器 healthy；`health` 返回版本 `0.3.1`；`ready` 数据库状态 `ok`；`alembic current` 为 `20261014_0002 (head)`；测试出现 `SCHEMA SMOKE PASSED`、`TEST DATA ROLLED BACK` 且退出码 `0`。

## 安全提醒

- 当前**未开放**任何带身份认证的共享清单增删改查或「勾选已购买→自动入库」HTTP API；`purchase_and_stock` 仅为内部安全业务函数。
- 永远不要在公网开放 PostgreSQL 5432，也不要为了测试直接公网开放 FastAPI 8000。
- 请勿分享 `.env`、备份文件、SSH 私钥；业务用户密码必须使用安全密码哈希。
- 普通构建失败时保留旧容器，提供脱敏日志排查。升级前请保留备份和目前运行的 v0.2 镜像。
