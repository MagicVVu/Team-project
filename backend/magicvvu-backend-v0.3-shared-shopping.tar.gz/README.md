# MagicVVu Backend v0.3.1 — 家庭共享购物清单 / 购买自动入库（数据库基础）

基于已运行的 v0.2 FastAPI + PostgreSQL 17。**不开放未经认证的业务 CRUD 接口**。

## 本次实现

- 六张业务表和原 v0.3 `20261014_0001` 迁移保持不变。
- 新 `20261014_0002` 迁移：每户至多一张共享购物清单；购物项记录添加人、购买人；库存新增唯一来源清单项 ID。
- `app.services.shopping.purchase_and_stock()`：同一事务内将购物项标记已购买并创建库存批次；成员校验、行锁、唯一约束防重复。
- `python -m app.schema_smoke`：事务回滚式验证唯一清单、成员权限、入库、幂等性，**不会留下测试数据**。
- 健康检查 `GET /api/v1/health` 版本为 `0.3.1`；`GET /api/v1/ready` 保持不变。
- Compose 保留原 `backend`/`db` 服务、数据库卷、密码环境变量、仅本机 `127.0.0.1:8000`，只调整后端镜像标签。

## 尚未实现

用户注册登录、JWT 授权、可从 Android 调用的「勾选已购买」HTTP 接口、家庭清单初始化、图片管理和 AI Agent。不能将内部服务当成已经上线的 App 功能。

## 升级流程

请按 `README-v0.3-升级说明.md` 分段执行。**不含数据库密码或真实数据，不会在正常升级中删除数据库卷。**

## 目录

- `backend/app/models.py`：ORM 数据模型
- `backend/app/services/shopping.py`：购买入库内部业务服务
- `backend/app/schema_smoke.py`：回滚式数据库测试
- `backend/alembic/versions/20261014_0001_core_tables.py`：原始初版迁移（保持原样）
- `backend/alembic/versions/20261014_0002_shared_shopping.py`：本次增量迁移
- `docs/数据库设计-v0.3.md`：详细数据库设计
- `deploy/compose.yaml`：服务编排，保留原配置和数据卷
