"""MagicVVu backend application."""
