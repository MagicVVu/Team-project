# MagicVVu Backend v0.4 — 手机号 + 密码 / 家庭身份 API

> **注意：开发测试版。** 未接入短信，因此注册的手机号**未验证所有权**。`AUTH_ALLOW_UNVERIFIED_SIGNUP` 默认 false（禁止注册），在公网开放注册前必须增加短信验证、验证码频控、登录限流/锁定、HTTPS、风控、密码找回等。**不要用真实用户数据做公开试运行。**

## 1. 已开发的功能

- 接受中国大陆 11 位手机号（自动标准化为 `+86...`）或 E.164 国际格式。
- Argon2id 密码哈希；10–128 字符；不保存明文密码。
- 12 小时有效的随机 Bearer 令牌；数据库只存 SHA-256 摘要；支持注销和过期。
- 用户基本信息 `GET /api/v1/users/me`；手机号验证状态始终为 false。
- 创建家庭时，在同一事务内自动建立**唯一的一份家庭共享购物清单**。
- 查询当前用户的家庭和家庭成员；只有已登录且属于该家庭的成员有权读取成员列表。
- 家庭 owner/admin 可生成 30 分钟一次性邀请码；已登录用户可输入邀请码入家。
- 保留 v0.3 的购物清单数据库规则、内部购买自动入库逻辑以及 `health` / `ready`。

未实现：短信所有权验证、公网安全注册、重置密码、面向 Android 的库存和购物清单 HTTP 写接口、HTTPS 反代、请求限流/风控。购买后自动入库依然仅为**已测试的内部业务函数**。

## 2. 从已部署 v0.3.1 安全升级

下列命令都在 Ubuntu 的 `ssh magicvvu` 会话内执行。**始终保留 `deploy/.env`、PostgreSQL 数据卷，切勿 `docker compose down -v`。** 不使用 `set -e`。命令中 `BACKUP` 是你当前窗口的变量，保持同一会话执行。

1. Windows 上传：

   ```powershell
   scp "$env:USERPROFILE\Downloads\magicvvu-backend-v0.4-phone-auth.tar.gz" magicvvu:~/
   ```

2. 服务器预检（先运行）：

   ```bash
   set +e
   cd /srv/magicvvu/magicvvu-starter
   tar -tzf ~/magicvvu-backend-v0.4-phone-auth.tar.gz | head -40
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml ps
   ```

3. 代码和数据库备份。不要跳过：

   ```bash
   STAMP=$(date +%Y%m%d_%H%M%S)
   BACKUP="/srv/magicvvu/backups/v04_$STAMP"
   (umask 077; mkdir -p "$BACKUP")
   cp -a backend "$BACKUP/"
   cp -a deploy/compose.yaml "$BACKUP/compose.yaml"
   cp -a deploy/.env "$BACKUP/database-env.backup"
   chmod 600 "$BACKUP/database-env.backup"
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml exec -T db \
     sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" exec pg_dump -h 127.0.0.1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc --no-owner' \
     > "$BACKUP/postgres_before_v04.dump"
   echo "PG_DUMP_EXIT_CODE: $?"
   test -s "$BACKUP/postgres_before_v04.dump" && echo 'BACKUP_NONEMPTY'
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml exec -T db \
     pg_restore -l < "$BACKUP/postgres_before_v04.dump" > /dev/null
   echo "ARCHIVE_CHECK_EXIT_CODE: $?"
   ```

   只有两个退出码都为 0 且备份非空才继续。

4. 解压更新源码并检查：

   ```bash
   tar -xzf ~/magicvvu-backend-v0.4-phone-auth.tar.gz -C .
   echo "EXTRACT_EXIT_CODE: $?"
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml config --quiet
   echo "CONFIG_EXIT_CODE: $?"
   ```

5. 构建新版镜像（不替换运行中的后端）：

   ```bash
   timeout 360s sudo docker compose --env-file deploy/.env -f deploy/compose.yaml build backend
   echo "BUILD_EXIT_CODE: $?"
   ```

6. 构建成功并确认备份后执行迁移（这一步会**修改**真实数据库结构）：

   ```bash
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
     run --rm --no-deps backend alembic upgrade head
   echo "MIGRATION_EXIT_CODE: $?"
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml \
     run --rm --no-deps backend alembic current
   ```

   应显示 `20261014_0003 (head)`。若非零，暂停，不要 `alembic stamp`、`downgrade`、删表。

7. 迁移成功后替换后端并验收：

   ```bash
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml up -d --no-deps backend
   echo "DEPLOY_EXIT_CODE: $?"
   curl -i --max-time 10 http://127.0.0.1:8000/api/v1/health
   curl -i --max-time 10 http://127.0.0.1:8000/api/v1/ready
   sudo docker compose --env-file deploy/.env -f deploy/compose.yaml ps
   ```

   预期版本为 `0.4.0`、ready 返回数据库 OK。

## 3. 测试手机号注册（仅在 SSH 本机隧道，不开放公网）

默认 `POST /api/v1/auth/register` 返回 403 **是正确的安全行为**。如需内部联调，可在服务器上编辑 `deploy/.env` 增加：

```
MAGICVVU_ALLOW_UNVERIFIED_SIGNUP=true
```

然后执行 `sudo docker compose --env-file deploy/.env -f deploy/compose.yaml up -d --no-deps backend` 使环境变量生效，验证 Docker 端口仍为 `127.0.0.1:8000`（不要开放 8000 的公网防火墙端口）。Windows 再开一个 PowerShell 执行：

```powershell
ssh -N -L 18000:127.0.0.1:8000 magicvvu
```

另一个本地窗口打开 `http://127.0.0.1:18000/docs` 测试。密码不可上传到 GitHub 或聊天。**完成内部注册后，立即将 `MAGICVVU_ALLOW_UNVERIFIED_SIGNUP=false`，重新运行 `up -d --no-deps backend` 关闭新用户注册。** 已有账号仍可登录。

## 4. API 一览

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/v1/auth/register` | 内部测试注册；默认禁用，手机号未验证 |
| POST | `/api/v1/auth/login` | 手机号 + 密码；获取短期 Bearer Token |
| POST | `/api/v1/auth/logout` | 当前 Token 注销 |
| GET | `/api/v1/users/me` | 获取自己资料 |
| POST | `/api/v1/households` | 创建家庭，同时建立唯一购物清单 |
| GET | `/api/v1/households` | 查看自己所在家庭 |
| GET | `/api/v1/households/{household_id}/members` | 家庭成员列表 |
| POST | `/api/v1/households/{household_id}/invitations` | owner/admin 生成邀请码 |
| POST | `/api/v1/households/join` | 按邀请码加入家庭 |
| GET | `/api/v1/health` | 服务进程健康 |
| GET | `/api/v1/ready` | 数据库就绪 |

手机号注册样例（以下仅供**本地内测**，使用由你实际掌控的测试号码）：

```json
{"phone":"13800138000","password":"ReplaceWithStrongTestPassphrase!","display_name":"Test User"}
```

`13800138000` 为格式示例，**不是已验证的测试号码**。未发送短信前，任何人都可能冒用他人号码，且无法安全找回密码。不能以此功能作为公开生产认证。

## 5. 代码目录与测试

- `backend/app/routers/auth.py` — 注册、登录、注销、当前用户
- `backend/app/routers/households.py` — 家庭成员与邀请码权限
- `backend/app/dependencies.py` — Bearer 令牌认证与 DB session
- `backend/app/security.py` — Argon2id 与短期随机令牌
- `backend/app/schemas.py` — 请求/响应校验
- `backend/app/models.py` — 包含 v0.3 六张业务表和新增两张会话/邀请表
- `backend/alembic/versions/20261014_0003_phone_auth_households.py` — 非破坏性向前迁移，保留 email 历史数据
- `backend/tests/test_v04.py` — SQLite 隔离集成测试，不在生产数据库执行

本地验证通过：从 0002 迁移到 0003，旧邮箱用户记录保留，受控注册、手机号唯一、密码认证、注销、家庭创建时生成共享清单、邀请码一次性和权限校验。**仅 SQLite，本地测试不代表已经通过云上 PostgreSQL 及并发压力测试。**
