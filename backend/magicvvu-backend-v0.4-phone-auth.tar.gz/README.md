# MagicVVu Backend v0.4 — 开发内部联调版

FastAPI + SQLAlchemy + PostgreSQL 17 + Alembic + Argon2id。

用户登录设计：**手机号 + 密码，暂不发送短信**。在该阶段手机号只是一段登录标识，`phone_verified_at` 为空，不代表实际拥有该号码。

- 手机号可接受中国大陆 11 位（转 `+86`）或 E.164 格式。
- 内部测试注册默认禁用；通过 `MAGICVVU_ALLOW_UNVERIFIED_SIGNUP=true` 临时启用。
- 登录发 12 小时短期随机令牌；服务端仅存令牌摘要，可注销。
- 家庭空间与成员权限；创建家庭自动建立唯一共享购物清单。
- 邀请码 30 分钟有效、只可消费一次。
- v0.3 自动入库内部服务继续保留；暂无向 Android 开放的购买 API。
- 只在 SSH 隧道内开发测试，公网开放前必须增加手机号码验证、限流、HTTPS 和账号恢复机制。

完整升级说明：`README-v0.4-升级说明.md`。
