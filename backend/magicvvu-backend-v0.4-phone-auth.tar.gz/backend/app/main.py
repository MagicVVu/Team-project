"""MagicVVu v0.4: phone/password (unverified development mode) and households."""

import logging

from fastapi import FastAPI, HTTPException
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.database import engine
from app.routers.auth import router as auth_router
from app.routers.households import router as household_router

logger = logging.getLogger(__name__)

app = FastAPI(
    title="MagicVVu API",
    description="v0.4 development-only phone/password identity and household API; HTTPS and SMS verification pending",
    version="0.4.0",
)
app.include_router(auth_router)
app.include_router(household_router)


@app.get("/api/v1/health", tags=["System"])
def health_check() -> dict[str, str]:
    return {"status": "ok", "service": "magicvvu-backend", "version": "0.4.0"}


@app.get("/api/v1/ready", tags=["System"])
def readiness_check() -> dict[str, str]:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except SQLAlchemyError:
        logger.exception("Database readiness query failed")
        raise HTTPException(status_code=503, detail="Database unavailable") from None
    return {"status": "ready", "database": "ok"}
