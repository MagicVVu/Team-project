"""MagicVVu HTTP routers."""
