# MagicVVu 数据库连接升级包 v0.2

这是对**已运行中的** `/srv/magicvvu/magicvvu-starter` 的覆盖升级包，不含密码或 PostgreSQL 数据文件。

## 本版提供

- 保留 `GET /api/v1/health`（返回版本 `0.2.0`）
- 新增 `GET /api/v1/ready`：通过 SQLAlchemy 执行 `SELECT 1` 验证 FastAPI 到 PostgreSQL 的真实连接
- SQLAlchemy + psycopg3，同步连接池最多 2 个连接，不使用本地数据库端口
- Alembic 基础框架，**未创建任何业务表，也未执行数据库迁移**
- 数据库仍使用原 Compose 项目名 `magicvvu-starter` 及命名卷 `postgres_data`
- PostgreSQL 17、端口仅内网；后端仅 `127.0.0.1:8000`

## 安全说明

- 不要上传 `deploy/.env`、密钥或数据库备份到 GitHub。
- 当前后端连接的是 PostgreSQL 初始化管理角色，仅用于开发阶段；业务 API 正式上线前应改为独立、最小权限的应用角色。
- 不要运行 `docker compose down -v`；这会删除数据库卷。
- 不要将 `8000` 或 `5432` 暴露到公网。
- 准备业务表前应先设计数据模型，再通过 Alembic 迁移并备份数据库。
