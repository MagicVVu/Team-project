# MagicVVu Backend v0.2

FastAPI + PostgreSQL 17 baseline. The backend listens on localhost only.

## Endpoints

- `GET /api/v1/health`: HTTP process health, returns version `0.2.0`
- `GET /api/v1/ready`: SQLAlchemy query `SELECT 1` against PostgreSQL
- `/docs`: OpenAPI interface

## Run on the Alibaba Cloud Ubuntu host

From `/srv/magicvvu/magicvvu-starter`:

```bash
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml config --quiet
sudo docker compose --env-file deploy/.env -f deploy/compose.yaml up -d --no-deps --build backend
curl -i http://127.0.0.1:8000/api/v1/health
curl -i http://127.0.0.1:8000/api/v1/ready
```

Do not expose ports 8000 or 5432 to the public Internet. Do not commit `deploy/.env`.
The Alembic directory is a scaffold only: no business tables/migrations have been created.
