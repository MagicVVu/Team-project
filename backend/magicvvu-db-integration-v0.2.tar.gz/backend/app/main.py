"""MagicVVu API: app health and database readiness (no business API yet)."""

import logging

from fastapi import FastAPI, HTTPException
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.database import engine

logger = logging.getLogger(__name__)

app = FastAPI(
    title="MagicVVu API",
    description="MagicVVu backend: API and database connectivity baseline",
    version="0.2.0",
)


@app.get("/api/v1/health", tags=["System"])
def health_check() -> dict[str, str]:
    """Liveness: the HTTP process can answer requests, independent of the DB."""
    return {"status": "ok", "service": "magicvvu-backend", "version": "0.2.0"}


@app.get("/api/v1/ready", tags=["System"])
def readiness_check() -> dict[str, str]:
    """Readiness: the application can execute a query through SQLAlchemy."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except SQLAlchemyError:
        logger.exception("Database readiness query failed")
        raise HTTPException(status_code=503, detail="Database unavailable") from None

    return {"status": "ready", "database": "ok"}
